// 1. Inisialisasi AOS (Animasi Scroll)
AOS.init({ duration: 1000, once: true });

// 2. Preloader (Loading Screen)
window.addEventListener('load', () => {
    const loader = document.getElementById('preloader');
    loader.style.opacity = '0';
    setTimeout(() => { loader.style.display = 'none'; }, 500);
});

// 3. Navbar Scroll Effect
window.onscroll = () => {
    const nav = document.getElementById('navbar');
    window.scrollY > 50 ? nav.classList.add('scrolled') : nav.classList.remove('scrolled');
};

// 4. Lightbox Global Function
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxCaption = document.getElementById('lightbox-caption');

function openFullView(src, title, subtitle) {
    lightboxImg.src = src;
    lightboxCaption.innerHTML = `
        <h3 style="color:white; margin-top:20px">${title}</h3>
        <p style="color:#ddd">${subtitle}</p>
    `;
    lightbox.style.display = 'flex';
}

// Event Klik Lukisan
document.querySelectorAll('.project-card').forEach(card => {
    card.addEventListener('click', () => {
        const title = card.querySelector('h3').innerText;
        const artist = card.querySelector('strong').innerText;
        const src = card.querySelector('img').src;
        openFullView(src, title, `Karya oleh: ${artist}`);
    });
});

// Event Klik Profil Anggota (Sekarang Berfungsi)
document.querySelectorAll('.member-card').forEach(card => {
    card.addEventListener('click', () => {
        const name = card.querySelector('h4').innerText;
        const bday = card.querySelector('.role').innerText;
        const src = card.querySelector('img').src;
        openFullView(src, name, `Tanggal Lahir: ${bday}`);
    });
});

// Kontrol Penutup Lightbox
document.querySelector('.close-btn').onclick = () => lightbox.style.display = 'none';
lightbox.onclick = (e) => { if (e.target === lightbox) lightbox.style.display = 'none'; };

// 5. Dark Mode Logic
const btn = document.getElementById('dark-mode-toggle');
if (localStorage.getItem('theme') === 'dark') {
    document.body.classList.add('dark-mode');
    btn.innerText = '☀️';
}

btn.onclick = () => {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    btn.innerText = isDark ? '☀️' : '🌙';
};