// 1. Efek Scroll Navbar
window.onscroll = () => {
    const navbar = document.getElementById('navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
};

// 2. Logika Modal Lightbox
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxCaption = document.getElementById('lightbox-caption');
const closeBtn = document.querySelector('.close-btn');

// Fungsi pembuka Lightbox
const openLightbox = (imgSrc, captionHtml) => {
    lightboxImg.src = imgSrc;
    lightboxCaption.innerHTML = captionHtml;
    lightbox.style.display = 'flex';
};

const closeLightbox = () => {
    lightbox.style.display = 'none';
};

// -- A: Klik pada Kartu Lukisan (Galeri) --
document.querySelectorAll('.project-card').forEach(card => {
    card.addEventListener('click', () => {
        const title = card.querySelector('h3').innerText;
        const artist = card.querySelector('strong').innerText;
        const src = card.querySelector('img').src;
        
        const caption = `
            <h3 style="color:white; margin-top:20px">${title}</h3>
            <p style="color:#ddd">Karya: ${artist}</p>
        `;
        openLightbox(src, caption);
    });
});

// -- B: Klik pada Foto ATAU Nama Anggota Tim --
document.querySelectorAll('.member-card').forEach(card => {
    // Ambil elemen foto (avatar) dan nama (h4)
    const avatar = card.querySelector('.avatar');
    const nameLink = card.querySelector('h4');

    // Beri kursor pointer agar user tahu keduanya bisa diklik
    avatar.style.cursor = 'pointer';
    nameLink.style.cursor = 'pointer';

    // Fungsi untuk menangani klik anggota tim
    const handleMemberClick = () => {
        const name = nameLink.innerText;
        const role = card.querySelector('.role').innerText;
        const imgSrc = card.querySelector('img').src;
        
        const caption = `
            <h3 style="color:white; margin-top:20px">${name}</h3>
            <p style="color:#ddd">${role}</p>
        `;
        openLightbox(imgSrc, caption);
    };

    // Pasang event listener ke foto dan nama
    avatar.addEventListener('click', handleMemberClick);
    nameLink.addEventListener('click', handleMemberClick);
});

// -- C: Kontrol Penutup --
closeBtn.onclick = closeLightbox;
lightbox.onclick = (e) => { if (e.target === lightbox) closeLightbox(); };
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && lightbox.style.display === 'flex') closeLightbox();
});